#!/bin/bash
./parser.out $1