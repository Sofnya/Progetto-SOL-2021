#!/bin/bash
../client.out -t 0 -p -f test3Address -w testFiles,$(($RANDOM % 100)) -R$(($RANDOM % 100))