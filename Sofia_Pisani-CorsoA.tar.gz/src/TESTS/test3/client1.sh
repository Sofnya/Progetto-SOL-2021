#!/bin/bash
../client.out -t 0 -p -f test3Address -D miss -W  testFiles/hex -d read -r testFiles/hex -c testFiles/hex