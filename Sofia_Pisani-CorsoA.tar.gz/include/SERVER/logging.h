#ifndef LOGGING_H
#define LOGGING_H

int logger(char *msg, char *type);

#endif